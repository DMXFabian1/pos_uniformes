"""Utilidades y configuracion compartida."""
